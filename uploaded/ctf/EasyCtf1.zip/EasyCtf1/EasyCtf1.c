#include <stdio.h>
#include <string.h>

int main()
{
	int var0 = 45332;
	int var1;
	
	printf("\n\nHi there. It's me, sharkSniffer.\nEnter password: ");
	scanf("%d", &var1);
	
	if( var0 == var1)
	{
		printf("\n\nCorrect Password!\n");
	}
	else
	{
		printf("\n\nWrong Password!\n");
	}
	return 0;
}