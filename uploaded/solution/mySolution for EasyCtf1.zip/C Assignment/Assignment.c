// NAME : MUHAMMAD YASIN BIN ABDUL HASSIM
// STU ID : 2016 782 863
// GROUP : CS110 5A

#include <stdio.h>
#include <string.h>

struct student
{
	char name[50];
	int id;
	char program[20];
};

int searchByProgramme( struct student arr[], int size);

int main()
{
	struct student uitm[10];
    int foo = 10;
    int total;

	for(int i=0; i<10; i++)
	{
		printf(" \n\nEnter student name : ");
		scanf(" %s", uitm[i].name);
		printf(" \nEnter student id : ");
		scanf(" %d", &uitm[i].id);
		printf(" \nEnter student program : ");
		scanf(" %s", uitm[i].program);
	}

	for( int j=0; j<10; j++)
	{
		printf(" \n\nStudent Name : %s", uitm[j].name);
		printf(" \nStudent ID: %d", uitm[j].id);
		printf(" \nStudent Program: %s\n", uitm[j].program);
	}
	
	total = searchByProgramme( uitm, foo);
    
    printf("\n\nTotal Student with same Programme : %d\n", total);
	
	return 0;
}	

int searchByProgramme( struct student arr[], int size)
{
	char prog[20];
	int total = 0;
    
	printf("\n\nPlease enter programme code : ");
	scanf(" %s", prog);
    
	for(int i = 0; i < size; i++)
	{
		if( strcmp(prog, arr[i].program) == 0)
        {
			total++;
            printf("\n\nStudent Name : %s", arr[i].name);
            printf("\nStudent ID : %d", arr[i].id);
            printf("\nStudent Program : %s", arr[i].program);
        }
	}
	return total;
}
